//
//  main.cpp
//  8-puzzle
//
//  Created by 谭演锋 on 2023/5/20.
//

#include <iostream>
#include "TreeSearch.hpp"
using namespace std;

int main(int argc, const char * argv[]) {
    // insert code here...
    MySearch ms;
    ms.searchHelp(0);
    ms.searchHelp(1);
    ms.searchHelp(2);
    ms.searchHelp(3);
    return 0;
}
