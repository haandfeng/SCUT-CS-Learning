from django.apps import AppConfig


class PhtrsConfig(AppConfig):
    
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PHTRS'
