package com.shr.phtrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhtrsApplicationTests {

    @Test
    void contextLoads() {
    }

}
