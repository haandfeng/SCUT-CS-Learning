package com.shr.phtrs.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.shr.phtrs.model.User;
import com.shr.phtrs.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@Controller
public class loginController {

    @Autowired
    LoginService loginService;

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    ResponseEntity<String> login(@RequestBody HashMap<String, String> map){
        String userName = map.get("userName");
        String password = map.get("password");
        User user = loginService.getUserByUserNameAndPassword(userName, password);
        Map<String, String> status = new HashMap<String, String>();
        if (user == null){
            status.put("isSuccessful", "false");
            return new ResponseEntity<>(JSON.toJSONString(status), HttpStatus.OK);
        }
        else {
            status.put("isSuccessful", "true");
            status.put("user_type", user.getUserType());
            return new ResponseEntity<>(JSON.toJSONString(status), HttpStatus.OK);
        }

    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    ResponseEntity<String> register(@RequestBody HashMap<String, String> map) {
        String userName = map.get("userName");
        String password = map.get("password");
        String userType = map.get("userType");
        if (loginService.checkUserExist(userName)) {
            return new ResponseEntity<>("user already exists!", HttpStatus.OK);
        } else if (!userType.equals("admin") && !userType.equals("citizen") && !userType.equals("worker")) {
            return new ResponseEntity<>("user type illegal!", HttpStatus.OK);
        } else {
            loginService.registerByUserNameAndPasswordAndUserType(userName, password, userType);
            return new ResponseEntity<>("OK", HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/user_info/get", method = RequestMethod.POST)
    ResponseEntity<String> get_info(@RequestBody HashMap<String, String> map){
        String userName = map.get("userName");

        User user = loginService.getUserByUserName(userName);
        if (user == null){
            return new ResponseEntity<>("user doesn't exist!", HttpStatus.OK);
        }

        Map<String, String> info = new HashMap<>();
        info.put("name", user.getName());
        info.put("mobile", user.getMobile());
        info.put("address", user.getAddress());
        return new ResponseEntity<>(JSON.toJSONString(info), HttpStatus.OK);
    }

    @RequestMapping(value = "/user_info/set", method = RequestMethod.POST)
    ResponseEntity<String> set_info(@RequestBody HashMap<String, String> map){
        String userName = map.get("userName");
        String name = map.get("name");
        String mobile = map.get("mobile");
        String address = map.get("address");
        if (!loginService.checkUserExist(userName)){
            return new ResponseEntity<>("user doesn't exist!", HttpStatus.OK);
        }
        else{
            loginService.updateUserInfo(userName, name, mobile, address);
            return new ResponseEntity<>("OK", HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/user_info/set_pwd", method = RequestMethod.POST)
    ResponseEntity<String> set_password(@RequestBody HashMap<String, String> map){
        String userName = map.get("userName");
        String oldPassword = map.get("oldPassword");
        String newPassword = map.get("newPassword");
        User user = loginService.getUserByUserNameAndPassword(userName, oldPassword);
        if (user == null){
            return new ResponseEntity<>("username or password is wrong", HttpStatus.OK);
        }
        else{
            loginService.updatePassword(userName, newPassword);
            return new ResponseEntity<>("OK", HttpStatus.OK);
        }
    }

//    @RequestMapping(value = "/temp", method = RequestMethod.POST)
//    ResponseEntity<String> temp(@RequestBody HashMap<String, Object> map){
//        for (String key : map.keySet()){
//            System.out.println(key+" : " + map.get(key).toString());
//        }
//        return new ResponseEntity<>("ok", HttpStatus.OK);
//    }
}
