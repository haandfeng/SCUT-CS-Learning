package com.shr.phtrs.controller;


import com.alibaba.fastjson.JSON;
import com.shr.phtrs.dataClass.FullPotholeInfo;
import com.shr.phtrs.model.Pothole;
import com.shr.phtrs.service.LoginService;
import com.shr.phtrs.service.PotholeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;


@Controller
@RestController
@RequestMapping(value = "/workorder")
public class WorkOrderController {

    @Autowired
    PotholeService potholeService;

    @Autowired
    LoginService loginService;

    @RequestMapping(value = "/getAll", method = RequestMethod.POST)
    ResponseEntity<String> getAllPothole(@RequestBody HashMap<String, String> map){
        String userName = map.get("userName");
        if (!loginService.checkUserExist(userName)){
            return new ResponseEntity<>("user doesn't exist!", HttpStatus.OK);
        }
        List<FullPotholeInfo> all = potholeService.getAllPotholes();
        return new ResponseEntity<>(JSON.toJSONString(all), HttpStatus.OK);
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    ResponseEntity<String> createPothole(@RequestBody HashMap<String, String> map){
        return new ResponseEntity<>(potholeService.createPothole(map), HttpStatus.OK);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    ResponseEntity<String> updatePothole(@RequestBody HashMap<String, String> map){
        return new ResponseEntity<>(potholeService.updatePothole(map), HttpStatus.OK);
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    ResponseEntity<String> deletePothole(@RequestBody HashMap<String, String> map){
        return new ResponseEntity<>(potholeService.deletePothole(map), HttpStatus.OK);
    }
}
