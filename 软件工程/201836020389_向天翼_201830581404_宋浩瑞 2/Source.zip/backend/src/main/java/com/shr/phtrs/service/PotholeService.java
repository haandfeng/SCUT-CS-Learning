package com.shr.phtrs.service;

import com.shr.phtrs.DAO.PotholeDAO;
import com.shr.phtrs.dataClass.FullPotholeInfo;
import com.shr.phtrs.model.Pothole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

@Transactional
@Service
public class PotholeService {

    @Autowired
    PotholeDAO potholeDAO;

    @Autowired
    LoginService loginService;

    public List<FullPotholeInfo> getAllPotholes(){
        return potholeDAO.findAllPotholes();
    }

    public String createPothole(HashMap<String, String> map){
        if (!loginService.checkUserExist(map.get("userName"))){
            return "user doesn't exist!";
        }
        Pothole p = new Pothole();
        updatePObject(map, p);
        potholeDAO.save(p);
        return "OK";
    }

    public String updatePothole(HashMap<String, String> map){
        if (!loginService.checkUserExist(map.get("userName"))){
            return "user doesn't exist!";
        }
        int id;
        try {
            id = Integer.parseInt(map.get("id"));
        }catch (Exception e){
            return "id format error or id is null";
        }
        Pothole p = potholeDAO.findById(id);
        if (p == null){
            return "id not found!";
        }

        updatePObject(map, p);
        potholeDAO.save(p);
        return "OK";
    }

    public String deletePothole(HashMap<String, String> map){
        int id;
        try {
            id = Integer.parseInt(map.get("id"));
        }catch (Exception e){
            return "id format error or id is null";
        }

        Pothole p = potholeDAO.findById(id);
        if (p == null){
            return "id not found!";
        }
        potholeDAO.delete(p);
        return "OK";
    }

    private void updatePObject(HashMap<String, String> map, Pothole p) {
        p.setAddress(map.get("address"));
        p.setCost(map.get("cost"));
        p.setDevice(map.get("device"));
        p.setDistrict(map.get("district"));
        p.setDuration(map.get("duration"));
        p.setMaterial(map.get("material"));
        p.setPosition(map.get("position"));
        p.setPriority(map.get("priority"));
        p.setSize(map.get("size"));
        p.setStatus(map.get("status"));
        p.setWorkersId(map.get("workersId"));
        p.setTime(map.get("time"));

        p.setUserName(map.get("userName"));

    }
}
