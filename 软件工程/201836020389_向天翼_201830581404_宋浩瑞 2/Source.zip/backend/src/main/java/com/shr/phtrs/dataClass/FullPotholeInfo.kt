package com.shr.phtrs.dataClass

import com.shr.phtrs.model.Pothole
import com.shr.phtrs.model.User

data class FullPotholeInfo (val id:Int, val workersId:String = "", val cost:String = "", val userName:String = "",
val priority:String = "", val address:String = "", val duration:String = "", val size:String = "", val material:String = "",
val district:String = "", val position:String = "", val time:String = "", val device:String = "", val status:String = "",
                            val name:String = "", val connectingAddress: String = "", val mobile:String = ""){
    constructor(user:User, pothole: Pothole):
        this(pothole.id, pothole.workersId, pothole.cost, pothole.userName, pothole.priority, pothole.address,
        pothole.duration, pothole.size, pothole.material, pothole.district, pothole.position, pothole.time, pothole.device,
        pothole.status, user.name, user.address, user.mobile)

}
