package com.shr.phtrs.controller;


import com.shr.phtrs.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Controller
@RequestMapping(value = "/debug")
public class debugController {

    @Autowired
    LoginService loginService;

//    @RequestMapping(value = "/transactional", method = RequestMethod.POST)
//    public ResponseEntity<String> debugTransactional(@RequestParam("userName")String userName, @RequestParam("password")String password, @RequestParam("userType")String userType){
//        loginService.debugTransactional(userName, password, userType);
//        return new ResponseEntity<>("ok", HttpStatus.OK);
//    }
//
//    @RequestMapping(value = "/delete", method = RequestMethod.POST)
//    public ResponseEntity<String> debugDelete(@RequestParam("userName")String userName){
//        loginService.debugDelete(userName);
//        return new ResponseEntity<>("ok", HttpStatus.OK);
//    }
}
