package com.shr.phtrs.service;

import com.shr.phtrs.DAO.UserDAO;
import com.shr.phtrs.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Service
public class LoginService {
    @Autowired
    UserDAO userDAO;


    public void updateUserByUser(User user){
        userDAO.save(user);
    }

    public boolean checkUserExist(String userName){
        return userDAO.existsByUserName(userName);
    }

    public User getUserByUserName(String userName){
        return userDAO.findByUserName(userName);
    }
    public User getUserByUserNameAndPassword(String userName, String password){
        return userDAO.findByUserNameAndPassword(userName, password);
    }

    public void registerByUserNameAndPasswordAndUserType(String userName, String password, String userType){
        User user = new User();
        user.setUserName(userName);
        user.setPassword(password);
        user.setUserType(userType);
        userDAO.save(user);
    }

    public void updateUserInfo(String userName, String name, String mobile, String address){
        User user = getUserByUserName(userName);
        user.setName(name);
        user.setAddress(address);
        user.setMobile(mobile);
        userDAO.save(user);
    }

    public void updatePassword(String userName, String newPassword){
        User user = getUserByUserName(userName);
        user.setPassword(newPassword);
        userDAO.save(user);
    }

//    public void debugTransactional(String userName, String password, String userType){
//        User user = userDAO.findByUserName(userName);
//        if(user == null){
//            user = new User();
//        }
//        user.setUserName(userName);
//        user.setPassword(password);
//        user.setUserType(userType);
//        userDAO.save(user);
//    }
//
//    public void debugDelete(String userName){
//        User user = userDAO.findByUserName(userName);
//        if(user == null){
//            return;
//        }
//        userDAO.delete(user);
//    }
}
