package com.shr.phtrs.DAO;


import com.shr.phtrs.model.Pothole;
import com.shr.phtrs.dataClass.FullPotholeInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface PotholeDAO extends JpaRepository<Pothole, Integer> {
//    @Query("select p from Pothole p")
//    List<Pothole> findAllPotholes();

    @Query("select new com.shr.phtrs.dataClass.FullPotholeInfo(u, p) from Pothole p, User u where p.userName = u.userName")
    List<FullPotholeInfo> findAllPotholes();

    Pothole findById(int id);
}
