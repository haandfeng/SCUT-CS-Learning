package com.shr.phtrs.DAO;

import com.shr.phtrs.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UserDAO extends JpaRepository<User, Integer> {
    User findByUserNameAndPassword(String userName, String password);
    User findByUserName(String userName);
    Boolean existsByUserName(String userName);
    @Transactional
    void deleteByUserName(String userName);
}
