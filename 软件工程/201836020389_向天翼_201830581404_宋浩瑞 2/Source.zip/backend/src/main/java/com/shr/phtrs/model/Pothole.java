package com.shr.phtrs.model;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "pothole", schema = "phtrs")
@NoArgsConstructor
public class Pothole {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Basic
    @Column(name = "workers_id")
    private String workersId="";

    @Basic
    @Column(name = "cost")
    private String cost="";

    @Basic
    @Column(name = "user_name", nullable = false)
    private String userName="";

    @Basic
    @Column(name = "priority")
    private String priority="";

    @Basic
    @Column(name = "address")
    private String address="";

    @Basic
    @Column(name = "duration")
    private String duration="";

    @Basic
    @Column(name = "size")
    private String size="";

    @Basic
    @Column(name = "material")
    private String material="";

    @Basic
    @Column(name = "district")
    private String district="";

    @Basic
    @Column(name = "position")
    private String position="";

    @Basic
    @Column(name = "time")
    private String time="";

    @Basic
    @Column(name = "device")
    private String device="";

    @Basic
    @Column(name = "status")
    private String status="";

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWorkersId() {
        return workersId;
    }

    public void setWorkersId(String workersId) {
        if (workersId != null)
            this.workersId = workersId;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        if (cost != null)
            this.cost = cost;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        if (priority != null)
            this.priority = priority;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (address != null)
            this.address = address;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        if (duration != null)
            this.duration = duration;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        if (size != null)
            this.size = size;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        if (material != null)
            this.material = material;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        if (district != null)
            this.district = district;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        if (position != null)
            this.position = position;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        if (time != null)
            this.time = time;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        if (device != null)
            this.device = device;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if(status != null)
            this.status = status;
    }
}
