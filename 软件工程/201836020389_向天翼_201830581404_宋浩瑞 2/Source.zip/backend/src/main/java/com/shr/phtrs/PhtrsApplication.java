package com.shr.phtrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhtrsApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhtrsApplication.class, args);
    }

}
