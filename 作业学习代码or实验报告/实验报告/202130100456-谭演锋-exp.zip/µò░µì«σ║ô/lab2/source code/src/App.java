import com.test.view.Login;

public class App {

    public static void main(String[] args) {
        new Login();
    }
}
