package com.test.pojo;

public class ClazzAvgScore {

	private String clazz;


	private Double avgScore;

	public ClazzAvgScore() {
		
	}

	public String getClazz() {
		return clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	public Double getAvgScore() {
		return avgScore;
	}

	public void setAvgScore(Double avgScore) {
		this.avgScore = avgScore;
	}
}
