SELECT ID
FROM StudentCourse
WHERE CourseID = 'C2';
