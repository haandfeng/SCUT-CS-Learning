SELECT ID
FROM StudentCourse
WHERE CourseID = 'C1' AND Score > 80;
