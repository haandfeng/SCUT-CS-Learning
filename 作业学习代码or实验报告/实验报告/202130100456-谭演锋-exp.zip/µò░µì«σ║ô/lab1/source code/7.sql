SELECT ID, Name
FROM Student
WHERE Department = 'Computer Science';
