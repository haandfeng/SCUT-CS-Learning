SELECT Department, AVG(Age) AS AverageAge
FROM Student
GROUP BY Department;
