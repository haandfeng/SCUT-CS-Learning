<?php

namespace app\controller;

use think\Model;

class IndexModel extends Model
{
    protected $table = "kx_table";
}