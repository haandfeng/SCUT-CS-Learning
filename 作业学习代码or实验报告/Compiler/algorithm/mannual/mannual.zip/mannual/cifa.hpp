//
//  cifa.hpp
//  mannual
//
//  Created by 谭演锋 on 2023/6/13.
//

#ifndef cifa_hpp
#define cifa_hpp

#include <stdio.h>
#include <fstream>

void LexicAlanalysis(std::fstream& , std::fstream& );
#endif /* cifa_hpp */
